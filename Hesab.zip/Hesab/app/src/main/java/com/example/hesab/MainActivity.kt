package com.example.hesab

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Telephony
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var db: Db
    private var items by mutableStateOf(listOf<Tx>())
    private var note by mutableStateOf("")

    private fun refresh() { items = db.all() }

    private fun importInbox() {
        var n = 0
        contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms.BODY, Telephony.Sms.DATE), null, null, "date DESC LIMIT 500")?.use {
            while (it.moveToNext()) if (db.add(it.getString(0) ?: "", it.getLong(1))) n++
        }
        note = "$n تراکنش از پیامک‌های قبلی اضافه شد"
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Screen() }
            }
        }
    }

    private fun granted() = listOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS).all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    @Composable
    fun Screen() {
        val nf = remember { NumberFormat.getInstance(Locale("fa", "IR")) }
        var ok by remember { mutableStateOf(granted()) }
        val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            ok = granted(); if (ok) importInbox()
        }
        val inc = items.filter { it.type == "in" }.sumOf { it.amount }
        val exp = items.filter { it.type == "out" }.sumOf { it.amount }
        val byCat = (CATS + "").associateWith { c -> items.filter { it.type == "out" && it.cat == c }.sumOf { it.amount } }

        Surface(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text("حسابدار من", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    if (!ok) {
                        Button(onClick = { ask.launch(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)) }) {
                            Text("اجازه خواندن پیامک")
                        }
                    } else {
                        OutlinedButton(onClick = { importInbox() }) { Text("خواندن پیامک‌های قبلی") }
                    }
                    if (note.isNotEmpty()) Text(note, style = MaterialTheme.typography.bodySmall)
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("واریزی: ${nf.format(inc)} ریال", color = Color(0xFF0F7B5F), fontWeight = FontWeight.Bold)
                            Text("برداشت: ${nf.format(exp)} ریال", color = Color(0xFFB3382C), fontWeight = FontWeight.Bold)
                            Divider(Modifier.padding(vertical = 6.dp))
                            byCat.forEach { (c, v) ->
                                Text("${c.ifEmpty { "بدون دسته" }}: ${nf.format(v)}", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                items(items, key = { it.id }) { t ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text((if (t.type == "in") "واریز " else "برداشت ") + nf.format(t.amount),
                                    fontWeight = FontWeight.Bold,
                                    color = if (t.type == "in") Color(0xFF0F7B5F) else Color(0xFFB3382C))
                                TextButton(onClick = { db.delete(t.id); refresh() }) { Text("حذف") }
                            }
                            Text(t.date + (t.balance?.let { " — مانده: " + nf.format(it) } ?: ""),
                                style = MaterialTheme.typography.bodySmall)
                            if (t.type == "out") {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    CATS.forEach { c ->
                                        FilterChip(selected = t.cat == c, onClick = { db.setCat(t.id, c); refresh() }, label = { Text(c) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
