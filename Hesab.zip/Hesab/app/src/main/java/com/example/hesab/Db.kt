package com.example.hesab

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Tx(val id: Long, val type: String, val amount: Long, val balance: Long?, val date: String, val cat: String)

val CATS = listOf("ماشین", "خوردنی", "ضروریات", "خرج خانم", "سایر")

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "hesab.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, amount INTEGER, balance INTEGER, date TEXT, ts INTEGER, cat TEXT DEFAULT '', raw TEXT, UNIQUE(ts, raw))")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun add(body: String, ts: Long): Boolean {
        val p = SmsParser.parse(body) ?: return false
        val v = ContentValues().apply {
            put("type", p.type); put("amount", p.amount); put("balance", p.balance)
            put("date", p.date); put("ts", ts); put("raw", body)
        }
        return writableDatabase.insertWithOnConflict("tx", null, v, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun setCat(id: Long, cat: String) {
        writableDatabase.update("tx", ContentValues().apply { put("cat", cat) }, "id=?", arrayOf(id.toString()))
    }

    fun delete(id: Long) { writableDatabase.delete("tx", "id=?", arrayOf(id.toString())) }

    fun all(): List<Tx> {
        val out = mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT id,type,amount,balance,date,cat FROM tx ORDER BY ts DESC", null).use {
            while (it.moveToNext()) out += Tx(it.getLong(0), it.getString(1), it.getLong(2),
                if (it.isNull(3)) null else it.getLong(3), it.getString(4), it.getString(5))
        }
        return out
    }
}
