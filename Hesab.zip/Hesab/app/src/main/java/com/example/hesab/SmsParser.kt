package com.example.hesab

import android.icu.text.SimpleDateFormat
import android.icu.util.ULocale
import java.util.Date

data class Parsed(val type: String, val amount: Long, val balance: Long?, val date: String)

object SmsParser {
    private val I = RegexOption.IGNORE_CASE
    private val dep = Regex("واریز|دریافت|سپرده|بستانکار|deposit|credit", I)
    private val wd = Regex("برداشت|خرید|پرداخت|انتقال|کسر|بدهکار|withdraw|debit|purchase", I)
    private val dateRx = Regex("\\d{2,4}[/\\-]\\d{1,2}[/\\-]\\d{1,2}")

    private fun norm(s: String) = buildString {
        for (c in s) append(when (c) {
            in '۰'..'۹' -> '0' + (c - '۰')
            in '٠'..'٩' -> '0' + (c - '٠')
            '٬', '،' -> ','
            else -> c
        })
    }

    fun today(): String =
        SimpleDateFormat("yyyy/MM/dd", ULocale("en@calendar=persian")).format(Date())

    fun parse(body: String): Parsed? {
        val t = norm(body)
        val type: String = when {
            Regex("(^|[\\s:])\\+\\s?\\d").containsMatchIn(t) -> "in"
            Regex("(^|[\\s:])-\\s?\\d").containsMatchIn(t) -> "out"
            else -> {
                val d = dep.find(t)?.range?.first ?: -1
                val w = wd.find(t)?.range?.first ?: -1
                if (d >= 0 && (w < 0 || d < w)) "in" else if (w >= 0) "out" else return null
            }
        }
        val balRx = "(?:مانده|موجودی|balance)[^\\d]*"
        val bal = Regex("$balRx([\\d,]+)", I).find(t)?.groupValues?.get(1)
            ?.replace(",", "")?.toLongOrNull()
        val c = t.replace(Regex("$balRx[\\d,.]+", I), "")
            .replace(dateRx, "")
            .replace(Regex("\\d{1,2}:\\d{2}(:\\d{2})?"), "")
            .replace(Regex("(?:کارت|حساب|شماره|card)[^\\d]{0,6}[\\d*\\-]+", I), "")
        val m = Regex("\\d{1,3}(?:,\\d{3})+|\\d{4,}").find(c) ?: return null
        var amount = m.value.replace(",", "").toLongOrNull() ?: return null
        if (c.contains("تومان")) amount *= 10
        val date = dateRx.find(t)?.value?.replace('-', '/') ?: today()
        return Parsed(type, amount, bal, date)
    }
}
